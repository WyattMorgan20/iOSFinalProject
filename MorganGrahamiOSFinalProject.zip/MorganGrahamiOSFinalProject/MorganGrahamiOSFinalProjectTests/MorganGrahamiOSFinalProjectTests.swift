//
//  MorganGrahamiOSFinalProjectTests.swift
//  MorganGrahamiOSFinalProjectTests
//
//  Created by Wyatt Morgan on 4/2/25.
//

import Testing
@testable import MorganGrahamiOSFinalProject

struct MorganGrahamiOSFinalProjectTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
